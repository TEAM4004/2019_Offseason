
function main()
{

localStorage.generateCSV = false;
localStorage.path_0 = [];
localStorage.path_1 = [];
localStorage.path_2 = [];
localStorage.path_3 = [];
// The front of the drive base is colored yellow for a rotational reference.
var csv = "";

// Let the use input values manually. If this is false, use the arrow keys to mimic joystick input, and the "q" and "w" keys to mimic rotational input.
var manualInput = false;

// All of these inputs should not exceed the range of -1 to 1.
var FWD = 0.000;
var STR = 0.000;
var RCW = 0.000;

// Length and width of your drive base.
var L = 60;
var W = 60;

var maximumWheelAcceleration = 1;

var sourceFolder = "./paths/";

var imagePath = "./fieldImage_two.PNG";

var pathData = [sourceFolder+"path_0.csv",sourceFolder+"path_1.csv",sourceFolder+"path_2.csv",sourceFolder+"path_3.csv",sourceFolder+"path_4.csv"];

var loadedPaths = [];

frameRate(60);

document.getElementById("angle").value = 90;
document.getElementById("a").value = 0.2;
document.getElementById("b").value = 0.8;
document.getElementById("tolerance").value = 0.001;
document.getElementById("k").value = 0.5;
document.getElementById("maximumVelocity").value = 7;
document.getElementById("maximumAcceleration").value = 7/3;



var spacing = 6;

// [x, y, TargetVelocity]

var path = [];
var bb = 0.8;

var aa = 1-bb;

var tolerance = 0.001;

var kValue = 0.5;

var maximumVelocity = 7;

var maximumAcceleration = maximumVelocity/3;

var pixelsPerInch = 2.84693;

var framesPerSecond = 120;

var maximumTravelVelocity = maximumVelocity*12*pixelsPerInch/framesPerSecond


// Precision of wheel speed calculations.
var precisionDecimalNumber = 3;

var createCSV = false;

frameRate(100);

var lookAheadRadius = 40;

var startPos = [182.4,575.7,0,90]

var startAngle = startPos[3];

var totalMovement = new PVector(startPos[0], -startPos[1], startPos[2]);

var maxAccl = 0.03;

var poses = [];

// [x, y, TargetVelocity]

var pathToFollow = [];

//var path = [[16,587],[191,593],[383,568],[494,490],[547,397],[559,310],[543,213],[514,121],[447,47],[360,17],[244,16],[141,28],[78,61],[52,138],[72,229],[125,292],[193,315],[279,315],[320,263],[325,185],[283,162],[234,161],[221,213],];

//var path = [[28,575],[322,545],[106,391],[335,343],[443,463],[399,554],[553,497],[528,66],[113,61],[99,223],[331,193],[77,354],[11,305],];

//var path = [[11,587],[112,104],[284,558],[431,101],[561,578],];

//var path = [[12,589],[206,585],[352,527],[499,567],[557,455],[441,371],[306,365],[187,382],[49,364],[53,238],[550,243],[552,61],[437,28],[423,51],[385,70],[354,58],[329,36],[262,38],[188,44],[152,64],[112,45],[59,40],];

/*
var drawPath = function(Path) {
    fill(255, 0, 0);
    stroke(0, 0, 0);
    strokeWeight(3);
    var x1 = 0;
    var y1 = 0;
    var x2 = 0;
    var y2 = 0;
    stroke(0, 0, 0);
    for (var i = 0; i < Path.length-1; i++) {
        x1 = Path[i][0];
        y1 = Path[i][1];
        x2 = Path[i+1][0];
        y2 = Path[i+1][1];
        line(x1, y1, x2, y2);
    }
    
    for(var i = 0; i < Path.length; i++) {
        x1 = Path[i][0];
        y1 = Path[i][1];
        ellipse(x1, y1, 10, 10);
    }
    strokeWeight(1);
};
*/

var indexes = [];



var currentIndex = 0;
var otherCurrentIndex = 0;
var prevIntersectionPoint = 0;
var vel = 0;
var preVel = 0;

var pathsLoaded = false;

var dot = function(a, b) {
    return a.x*b.x + a.y*b.y + a.z*b.z;
};

var intersectionPoint = [];
var closestPoint = 0;

var chooseFollowingPoint = function(positionx, positiony, radius, Path, tempPath) {
    var closestIndex = -100;
    var lookAhead = -100;
    var prevDistance = 100000;
    var prevMag = 9999;
    var E = 0;
    var L = 0;
    var C = 0;
    var r = lookAheadRadius;

    var d = 0;
    var f = 0;
    var a = new PVector();
    var b = new PVector();
    var c = new PVector();
    var discriminant = new PVector();
    var t1 = new PVector();
    var t2 = new PVector();
    var data = 0;
    
    intersectionPoint = [];

    for (var i = currentIndex; i < Path.length-1; i++) {

        E = new PVector(Path[i][0]*pixelsPerInch,Path[i][1]*pixelsPerInch);
        L = new PVector(Path[i+1][0]*pixelsPerInch,Path[i+1][1]*pixelsPerInch);
        C = new PVector(positionx,-positiony);

        d = new PVector(L.x, L.y, L.z);
        d.sub(E);
        f = new PVector(E.x, E.y, E.z);
        f.sub(C);
        a = dot(d,d);
        b = 2*dot(f, d);
        c = dot(f,f) - r*r;
        discriminant = b*b - 4*a*c;
        
        if (discriminant < 0) {
            intersectionPoint = prevIntersectionPoint;
            vel = preVel;
        // no intersection
        }else{
            discriminant = sqrt(discriminant);
            t1 = (-b + discriminant)/(2*a);
            t2 = (-b - discriminant)/(2*a);
            if (t1 >= 0 && t1 <=1){
                if (indexes[i] < t1 || indexes.length-1 < i) {
                    indexes[i] = t1;
                }
                //return t1 intersection
                intersectionPoint = [(E.x + indexes[i] * d.x), (E.y + indexes[i] * d.y)];

                data = indexes;
            }else {
            }
            
            if (t2 >= 0 && t2 <=1){
                if (indexes[i] < t2 || indexes.length-1 < i) {
                    indexes[i] = t2;
                }
                
                //return t2 intersection
                intersectionPoint = [(E.x + indexes[i] * d.x), (E.y + indexes[i] * d.y)];

                data = d.x*t2;
            }else {
            }
            
            if (t1 >= 0 && t1 <=1 || t2 >= 0 && t2 <=1) {
                currentIndex = i;
                prevIntersectionPoint = intersectionPoint;
                preVel = vel;
            }else {
                intersectionPoint = prevIntersectionPoint;
                vel = preVel;
            }
            


            //otherwise, no intersection
        }
        
        if (intersectionPoint === []) {
            intersectionPoint = prevIntersectionPoint;
            vel = preVel;
        }

        if (true) {
            stroke(255, 0, 0);
            strokeWeight(3);
            line(Path[i][0]*pixelsPerInch,Path[i][1]*pixelsPerInch,Path[i+1][0]*pixelsPerInch,Path[i+1][1]*pixelsPerInch);
            stroke(0, 0, 0);
            strokeWeight(1);
        }
        
    }

    var prevDistance = new PVector(10000,10000);
    for (var i = otherCurrentIndex; i < Path.length; i++) {
        var distance = new PVector(positionx-Path[i][0]*pixelsPerInch,-positiony-Path[i][1]*pixelsPerInch);
        if (distance.mag() < prevDistance.mag()) {
            prevDistance = distance;
            vel = Path[i][2];
            closestPoint = i;
            otherCurrentIndex = i;
        }
    }

    if (intersectionPoint !== 10000) {
        fill(0, 255, 0);
        ellipse(intersectionPoint[0], intersectionPoint[1], 10, 10);

    }

    return intersectionPoint;
};



var rotation = 0;

var count = 0;
var frspeed = [];
var flspeed = [];
var brspeed = [];
var blspeed = [];

var frangle = [];
var flangle = [];
var brangle = [];
var blangle = [];

rectMode(CENTER);
angleMode = "degrees";

var pi = 3.14159265358979323846264338327950288419716939937510;

var R = sqrt(sq(L) + sq(W));

var A;
var B;
var C;
var D;

var ws1;
var ws2;
var ws3;
var ws4;

var wa1;
var wa2;
var wa3;
var wa4;





var calculateTheSend = function() {
    A = STR - RCW * (L/R);
    B = STR + RCW * (L/R);
    C = FWD - RCW * (W/R);
    D = FWD + RCW * (W/R);
    
    ws1 = sqrt(sq(B) + sq(C));
    ws2 = sqrt(sq(B) + sq(D));
    ws3 = sqrt(sq(A) + sq(D));
    ws4 = sqrt(sq(A) + sq(C));
    
    wa1 = atan2(B,C);
    wa2 = atan2(B,D);
    wa3 = atan2(A,D);
    wa4 = atan2(A,C);
    
};

var constrainWheelSpeeds = function() {
    var max;
    max = ws1;
    if (this.ws2 > max) {
        max = ws2;
    }
    if (ws3 > max) {
        max = ws3;
    }
    if (ws4 > max) {
        max = ws4;
    }
    if (max > 1) {
        ws1/=max;
        ws2/=max;
        ws3/=max;
        ws4/=max;
    }
    
    ws1 = ws1.toFixed(precisionDecimalNumber);
    ws2 = ws2.toFixed(precisionDecimalNumber);
    ws3 = ws3.toFixed(precisionDecimalNumber);
    ws4 = ws4.toFixed(precisionDecimalNumber);
};

var wheel = function(loc) {
    var loc = this.loc;
    var x;
    var y;
    var angle;
    var color1;
    var color2;
    var color3;
    var speed;
    var angle;
};

wheel.prototype.setAngle = function(angle) {
    this.angle = angle;
};

wheel.prototype.setColor = function(color1, color2, color3) {
    this.color1 = color1;
    this.color2 = color2;
    this.color3 = color3;
};

wheel.prototype.draw = function(display, speed) {
    stroke(0, 0, 0);
    fill(this.color1, this.color2, this.color3);
    pushMatrix();
    translate(this.x,this.y);
    rotate(this.angle);
    rect(0,0,20,10);
    line(0, 0, 0, -(30*speed));
    triangle(-5,-20*speed, 0,-30*speed,5,-20*speed); 
    popMatrix();
    if (display) {
        textSize(20);
        stroke(this.color1,this.color2,this.color3);
        text("Speed: " + this.speed, this.x-50, this.y + 50);
        text("Angle: " + this.angle.toFixed(precisionDecimalNumber), this.x-50, this.y + 70);
        stroke(0, 0, 0);
    }
};

var frontLeft = new wheel("frontLeft");
var frontRight = new wheel("frontRight");
var backRight = new wheel("backRight");
var backLeft = new wheel("backLeft");

frontRight.setColor(255,0,0);
frontLeft.setColor(50,255,0);
backLeft.setColor(0,0,255);
backRight.setColor(255,0,255);

var center = 0;
var average = [];

frontRight.x = L/2;
frontRight.y = -W/2;
frontLeft.x = -L/2;
frontLeft.y = -W/2;
backLeft.x = -L/2;
backLeft.y = W/2;
backRight.x = L/2;
backRight.y = W/2;


var keys = [];


var encoder = function() {
    var distance;
};

encoder.prototype.follow = function(dist) {
    this.distance += dist;
};

var fRight = new encoder();
var fLeft = new encoder();
var bRight = new encoder();
var bLeft = new encoder();

fRight.distance = 0;
fLeft.distance = 0;
bLeft.distance = 0;
bRight.distance = 0;

var fRightVector;
var fLeftVector;
var bRightVector;
var bLeftVector;

var currentAngle = startAngle;

var currentVelocity = 0;
var currentAcceleration = 0;

var velocitySetpoint = 0;

var temp = 0;

var preFWD = 0;
var preSTR = 0;

var dFWD = 0;
var dSTR = 0;

var pointToFollow = -100;

var my_i = 0;
var my_j = 0;
var completePaths = [];
    
    
    
 
    

    
    
    
    
    
    
var mode = "Generate";
    
    
    
    
    
    
    
var createCSVfile = function(Path) {
    var result = '';
    var lineDelimeter = '\n';
    var columnDelimeter = ',';
    var tempPath = [];
    for (var i = 0; i < Path.length; i++) {
        tempPath.push([0,0,0,0]);
        for (var j = 0; j < Path[i].length; j++) {
            tempPath[i][j] = Path[i][j];
        }
    }
    
    
    
    if (tempPath.length <= 0) {
        println("Path empty");
        return null;
    }else {
        
        var zero = [0,0,0];
        for (var i = 0; i < tempPath.length; i++) {
            tempPath[i][1] = (900/pixelsPerInch)-tempPath[i][1];

            result += str(tempPath[i][0]-zero[0]) + columnDelimeter + str(tempPath[i][1]-zero[1]) + columnDelimeter + tempPath[i][2] + columnDelimeter + tempPath[i][3] + lineDelimeter;
        }
        return result;
    }
};

var formatCSV = function(CSV) {    
    for (var i = 0; i < CSV.length; i++) {
        CSV[i][1] = CSV[i][1];
    }
    for (var i = 0; i < CSV.length; i++) {
        for (var j = 0; j < CSV[i].length; j++) {
            CSV[i][j]*=1;
        }
        //CSV[i][0]+= startPos[0]/pixelsPerInch;
        //CSV[i][1]+= startPos[1]/pixelsPerInch;
        CSV[i][1] = (900/pixelsPerInch)-CSV[i][1];
    }

    return CSV;
};


var downloadCSV = function(args) {  
        var data;
        var filename;
        var link;
        
        if (csv == null) return;

        filename = args.filename || 'export.csv';

        var encodedUri = encodeURI(csv);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "my_data.csv");
        document.body.appendChild(link); // Required for FF

        link.click(); // This will download the data file named "my_data.csv".


};
    
var eWasPressed = false;

var wasPressed = false;

var generated = false;

var newPath = [];

var startPath = [startPos];

var rightMouseWasPressed = false;

var generatePath = function() {
    fill(153, 255, 0);
    stroke(0, 0, 0);
    strokeWeight(3);
    if (mouseX <= 900) {
        ellipse(mouseX, mouseY, 10, 10);
        if (mouseIsPressed && mouseButton === LEFT && !wasPressed) {
            generated = false;
            newPath = [];
            startPath.push([mouseX, mouseY,0,document.getElementById("angle").value]);
            wasPressed = true;
        }else if (!mouseIsPressed && wasPressed) {
            wasPressed = false;
        }
        
        if (mouseIsPressed && mouseButton === RIGHT && !rightMouseWasPressed) {
            generated = false;
            newPath = [];
            startPos = [mouseX, mouseY,0,document.getElementById("angle").value];
            startPath.unshift(startPos);
            startAngle = startPos[3];
            rightMouseWasPressed = true;
        }else if (!mouseIsPressed && rightMouseWasPressed) {
            rightMouseWasPressed = false;
        }
    }
    
};

var newerPath = [];
var drawPath = function(Path, inches, dotColor, lineColor, drawHeading, arrowColor, arrowFrequency) {
    strokeWeight(1);
    var x1 = 0;
    var y1 = 0;
    var x2 = 0;
    var y2 = 0;
    
    if (!inches) {
    
        for (var i = 0; i < Path.length-1; i++) {
            x1 = Path[i][0];
            y1 = Path[i][1];
            x2 = Path[i+1][0];
            y2 = Path[i+1][1];
            stroke(lineColor[0], lineColor[1], lineColor[2]);
            line(x1, y1, x2, y2);
        }
        noStroke();
        for(var i = 0; i < Path.length; i++) {
            x1 = Path[i][0];
            y1 = Path[i][1];
            fill(dotColor[0], dotColor[1], dotColor[2]);
            ellipse(x1, y1, 3, 3);
            if (drawHeading && (Number.isInteger(i/arrowFrequency) || i === Path.length-1 || i === 0)) {
                fill(arrowColor[0],arrowColor[1],arrowColor[2]);
                stroke(arrowColor[0],arrowColor[1],arrowColor[2]);
                pushMatrix();
                translate(x1,y1);
                rotate(Path[i][3]);
                line(0,0,0,-20);
                triangle(-5,-20, 0,-30,5,-20); 
                popMatrix();
            }
            stroke(lineColor[0], lineColor[1], lineColor[2]);
            strokeWeight(1);
        }
    }else {
        for (var i = 0; i < Path.length-1; i++) {
            x1 = Path[i][0]*pixelsPerInch;
            y1 = Path[i][1]*pixelsPerInch;
            x2 = Path[i+1][0]*pixelsPerInch;
            y2 = Path[i+1][1]*pixelsPerInch;
            stroke(lineColor[0], lineColor[1], lineColor[2]);
            line(x1, y1, x2, y2);
        }
        noStroke();
        for(var i = 0; i < Path.length; i++) {
            x1 = Path[i][0]*pixelsPerInch;
            y1 = Path[i][1]*pixelsPerInch;
            fill(dotColor[0], dotColor[1], dotColor[2]);
            ellipse(x1, y1, 3, 3);
            if (drawHeading && (Number.isInteger(i/arrowFrequency) || i === Path.length-1 || i === 0)) {
                fill(arrowColor[0],arrowColor[1],arrowColor[2]);
                stroke(arrowColor[0],arrowColor[1],arrowColor[2]);
                pushMatrix();
                translate(x1,y1);
                rotate(Path[i][3]);
                line(0,0,0,-20);
                triangle(-5,-20, 0,-30,5,-20); 
                popMatrix();
                stroke(lineColor[0], lineColor[1], lineColor[2]);
            }
        }
    }

};

var changes = [];

var number = 0;

var cached = false;
//37720
var smoothPath = function(Path, a, b, tolerance) {
    var tempPath = [];
    for (var i = 0; i < Path.length; i++) {
        tempPath.push([0,0,0,0]);
        for (var j = 0; j < Path[i].length; j++) {
                tempPath[i][j]+=(Path[i][j]);
        }
        
    }
    var change = tolerance;
    while (change >= tolerance) {
        change = 0;
        for (var i = 1; i < Path.length-1; i++) {
            for (var j = 0; j < 2; j++) {
                number+=1;
                var aux = tempPath[i][j];
                tempPath[i][j] += a * (Path[i][j] - tempPath[i][j]) + b * (tempPath[i-1][j] + tempPath[i+1][j] - 2.0 * tempPath[i][j]);
                change += abs(aux - tempPath[i][j]);
            }
        }
    }
    return tempPath;
    
};
//13.614065254328393
//13.614065254328393

var otherAverage = 0;
var prevNewPath;
rectMode(CENTER);
var keys = [];
var upWasPressed = false;
var leftWasPressed = false;
var temp = [];
var letter = "";
var originalPath = [];
var fieldImage = loadImage(imagePath);
var rightWasPressed = false;
var modeBool = false;
var deltaTime = 0;
var deltaFrames = 0;
var rWasPressed = false;
var pathsToFollow = [];
var useFiles = false;
var targetAngle = startAngle;

var rampedSpeeds = [0,0,0,0];


    draw = function()
    {
    
    bb = document.getElementById("b").value;

    aa = document.getElementById("a").value;

    tolerance = document.getElementById("tolerance").value;

    kValue = document.getElementById("k").value;

    maximumVelocity = document.getElementById("maximumVelocity").value;

    maximumAcceleration = document.getElementById("maximumAcceleration").value;
    
    if (document.getElementById("simMode").checked) {
        mode = "Follow";
    }else {
        mode = "Generate";
    }
    manualInput = document.getElementById("drive").checked;
    useFiles = !document.getElementById("useFiles").checked;
    
    background(200, 200, 200);
    image(fieldImage, 0, 0, 900, 900);



    //pathToFollow = newPath;
    keyPressed = function(){
        keys[keyCode] = true;
        letter = str(key);
  };
    keyReleased = function(){
        keys[keyCode] = false;
        letter = "";
    };
    if (letter === "m" && !rightWasPressed) {
        modeBool = !modeBool;
        rightWasPressed = true;
    }else if (letter !== "m") {
        rightWasPressed = false;
    }

    if (mode === "Generate") {
        if (letter === "g" && !upWasPressed) {

            if (newPath !== prevNewPath) {
                path = [];
                newPath = [];
                pathToFollow = [];
                for (var i = 0; i < startPath.length; i++) {
                    
                    originalPath.push([0,0,0,0]);
                    path.push([0,0,0,0]);
                    originalPath[i][0] = startPath[i][0];
                    originalPath[i][1] = startPath[i][1];
                    originalPath[i][2] = startPath[i][2];
                    originalPath[i][3] = startPath[i][3];

                    
                    path[i][0] = startPath[i][0]/pixelsPerInch;
                    path[i][1] = startPath[i][1]/pixelsPerInch;
                    path[i][2] = startPath[i][2];
                    path[i][3] = startPath[i][3];
                }
                prevNewPath = newPath;
                var vector = 0;
                for (var i = 0; i < path.length-1; i++) {
                    vector = new PVector(path[i][0]-path[i+1][0],path[i][1]-path[i+1][1]);
                    var numPointsThatFit = ceil(vector.mag()/spacing);
                    vector.normalize();
                    vector.x = -vector.x*spacing;
                    vector.y = -vector.y*spacing;
                    for (var j = 0; j < numPointsThatFit; j++) {
                        var newVector = new PVector();
                        newVector.x = vector.x*j;
                        newVector.y = vector.y*j;
                        newPath.push([path[i][0]+newVector.x,path[i][1]+newVector.y,0,path[i][3]]);
    
                    }
                }
                if (path.length > 0) {
                    newPath.push([path[path.length-1][0],path[path.length-1][1],0,path[path.length-1][3]]);
                }
                
                
                
                
                /*
                var myData = 0;
                for (var i = 0; i < newPath.length; i+=3) {
                    newerPath[myData] = [newPath[i][0],newPath[i][1],newPath[i][2]];
                    myData+=1;
                }
                */
            }
            newPath = smoothPath(newPath, aa, bb, tolerance);


            
            ///// Distance Between Points
            var distances = [];
            for (var i = 0; i <= newPath.length-1; i++) {
                if (i === 0) {
                    distances.push(0);
                }else {
                    var distance = new PVector(newPath[i][0]-newPath[i-1][0],newPath[i][1]-newPath[i-1][1]);
                    distances.push(distances[i-1] + distance.mag());            
                }
                
            }

            
            ///// Curvature of Path
            
            for (var i = 0; i <= newPath.length-1; i++) {
                var curvature;
                if (i === 0 || i === newPath.length-1) {
                    curvature = 0;
                    newPath[i][2] = maximumVelocity;
                }else {
                    
                    var P = new PVector(newPath[i][0]+0.00001,newPath[i][1]+0.000001);
                    var Q = new PVector(newPath[i-1][0],newPath[i-1][1]);
                    var R = new PVector(newPath[i+1][0],newPath[i+1][1]);
                    

                    var k1 = 0.5*(sq(P.x) + sq(P.y) - sq(Q.x) - sq(Q.y))/(P.x - Q.x);
                    var k2 = (P.y - Q.y)/(P.x - Q.x);
                    var b = 0.5*(sq(Q.x) - 2*Q.x*k1+sq(Q.y)-sq(R.x)+2*R.x*k1-sq(R.y))/(R.x*k2-R.y+Q.y-Q.x*k2);
                    var a = k1-k2*b;
                    var r = sqrt(sq(P.x-a) + sq(P.y-b));
                    curvature = 1/r;
                    if (curvature !== curvature) {
                        curvature = 0;
                    }
                    
                    var velocity = min(maximumVelocity, kValue/curvature);
                    newPath[i][2] = velocity;

                    
                }
                
            }

            
            newPath[newPath.length-1][2] = 0;
            //// Alterinng Velocities
            for (var i = newPath.length-2; i >= 0; i--) {
                var distance = new PVector(newPath[i+1][0]-newPath[i][0], newPath[i+1][1]-newPath[i][1]);
                var newVelocity = min(newPath[i][2], sqrt(sq(newPath[i+1][2])+2*maximumAcceleration*distance.mag()));
                newPath[i][2] = newVelocity;
                
            }
            for (var i = 0; i < newPath.length-1; i++) {
                // Divide the final velocity of each point in the path by the maximum velocity,
                // This gives you a percent power rather than a set in stone velocity.
                newPath[i][2] = newPath[i][2]/maximumVelocity;
            }
            

            
            
            
            
            
            
            
            upWasPressed = true;
            generated = true;
            createCSV = true;

        }else if (letter !== "g") {
            upWasPressed = false;
        }
        
        if (letter === "c") {
            path = [];
            newPath = [];
            startPath = [startPos];
            pathToFollow = [];
            generated = false;
        }
        
        if (letter === "t" && !leftWasPressed) {
            var index = startPath.length-1;
            startPath.splice(index, 1);
            newPath = [];
            leftWasPressed = true;
        }else if (letter !== "t") {
            leftWasPressed = false;
        }
        
        if (letter === "r" && !rWasPressed) {
            var index = 0;
            startPath.splice(index, 1);
            newPath = [];
            rWasPressed = true;
        }else if (letter !== "r") {
            rWasPressed = false;
        }
        
        generatePath();
        if (!generated) {
            drawPath(startPath, false,[255,255,255], [255,255,255],true,[255,0,255],1);
        }else {
            drawPath(newPath, true,[0,255,0], [0,255,0],true,[255,0,255],0);
            drawPath(startPath, false,[255,255,255],[255,255,255],true,[255,0,255],1);
        }
        fill(255, 255, 255);
        for (var i = 0; i < pathToFollow.length; i++) {
            indexes[i] = 0;
        }
        if (pathToFollow.length <= 0) {
            pathToFollow = [];
            for (var i = 0; i < newPath.length; i++) {
                pathToFollow.push([0,0,0,0]);
                pathToFollow[i][0] = newPath[i][0];
                pathToFollow[i][1] = newPath[i][1];
                pathToFollow[i][2] = newPath[i][2];
                pathToFollow[i][3] = newPath[i][3];

            }   
        }else {
            for (var i = 0; i < newPath.length; i++) {
                pathToFollow[i][0] = newPath[i][0];
                pathToFollow[i][1] = newPath[i][1];
                pathToFollow[i][2] = newPath[i][2];
                pathToFollow[i][3] = newPath[i][3];

            }
        }
    deltaFrames = frameCount;
    totalMovement.x = startPos[0];
    totalMovement.y = -startPos[1];
    totalMovement.z = startPos[2];
    currentIndex = 0;
    otherCurrentIndex = 0;
    prevIntersectionPoint = [];
    intersectionPoint = [];
    poses = [];
    pathsLoaded = false;
    angle = 0;
    deltaMovement = new PVector(0,0);
    pathsToFollow = [[]];
    my_i = 0;
    currentAngle = startAngle;
    targetAngle = startAngle;


    }else if (mode === "Follow") {

        if (!pathsLoaded) {
            if (useFiles) {
                pathsToFollow = [formatCSV($.csv.toArrays(localStorage.path_0)),formatCSV($.csv.toArrays(localStorage.path_1)),formatCSV($.csv.toArrays(localStorage.path_2)),formatCSV($.csv.toArrays(localStorage.path_3))];
            }else {
                for (var i = 0; i < newPath.length; i++) {
                    pathsToFollow[0].push([0,0,0,0]);
                    pathsToFollow[0][i][0] = newPath[i][0];
                    pathsToFollow[0][i][1] = newPath[i][1];
                    pathsToFollow[0][i][2] = newPath[i][2];
                    pathsToFollow[0][i][3] = newPath[i][3];

                }
            }
            
            my_i = 0;                

            for (var i = 0; i < pathsToFollow.length; i++) {
                completePaths.push(false);
            }
            pathsLoaded = true;
        }
        

        var deltaMovement = new PVector(0,0);
    
        preFWD = FWD;
        preSTR = STR;


        currentVelocity = new PVector(FWD, STR);
    

        if (manualInput) {
            currentAngle+=RCW*2;
            if (keys[UP]) {
                dFWD = 1;
            }else if (keys[DOWN]) {
                dFWD = -1;
            }else {
                dFWD = 0;
            }
            if (keys[LEFT]) {
                dSTR = -1;
            }else if (keys[RIGHT]){
                dSTR = 1;
            }else {
                dSTR = 0;
            }
            if (keys[81]) {
                RCW = -1;
            }else if (keys[87]) {
                RCW = 1;
            }else {
                RCW = 0;
            }
        }else {
            currentAngle*=1;
            if (currentAngle > targetAngle) {    
                currentAngle-=1;
            }else if (currentAngle < targetAngle) {
                currentAngle+=1;
            }
        }
 
        if (!manualInput) {
            if (pointToFollow !== -100) {
                
            
                var xDifference = (intersectionPoint[0] - totalMovement.get().x);
                var yDifference = (intersectionPoint[1] + totalMovement.get().y);

                var angle = atan2(xDifference, yDifference);
                
                
                var xValue = sin(angle)*vel;
                
                var yValue = cos(angle)*vel;
                /*    
                constrain(yDifference,-1,1);
                constrain(xDifference,-1,1);
                */

                dFWD = -yValue;
                dSTR = xValue;
                
            }


        }
        temp  =  dFWD * cos(currentAngle) + dSTR * sin(currentAngle);
        dSTR   = -dFWD * sin(currentAngle) + dSTR * cos(currentAngle);
        dFWD   =  temp;

        
        if (abs(dFWD - preFWD) <= maxAccl) {
            FWD = dFWD;
        }else {
            if (dFWD - preFWD > 0) {
                FWD = preFWD+maxAccl;
            }else if(dFWD - preFWD < 0) {
                FWD = preFWD-maxAccl;
            }
        }

        if (abs(dSTR - preSTR) <= maxAccl) {
            STR = dSTR;
        }else {
            if (dSTR - preSTR > 0) {
                STR = preSTR+maxAccl;
            }else if(dSTR - preSTR < 0) {
                STR = preSTR-maxAccl;
            }
        }
        
        calculateTheSend();
        constrainWheelSpeeds();
        
        var targetSpeeds = [ws1,ws2,ws3,ws4];
        
        for (var i = 0; i < rampedSpeeds.length; i++) {
            var data = 0;
            rampedSpeeds[i]*=1;
            if (rampedSpeeds[i] < targetSpeeds[i]) {
                rampedSpeeds[i]+=maximumWheelAcceleration;
                rampedSpeeds[i] = constrain(rampedSpeeds[i], rampedSpeeds[i], targetSpeeds[i]);
            }else if (rampedSpeeds[i] > targetSpeeds[i]) {
                rampedSpeeds[i]-=maximumWheelAcceleration;
                rampedSpeeds[i] = constrain(rampedSpeeds[i], targetSpeeds[i], rampedSpeeds[i]);
            }
            
        }
        
        ws1 = rampedSpeeds[0];
        ws2 = rampedSpeeds[1];
        ws3 = rampedSpeeds[2];
        ws4 = rampedSpeeds[3];
        
        
        frontRight.speed = ws1;
        frontLeft.speed = ws2;
        backLeft.speed = ws3;
        backRight.speed = ws4;
        
        
        fRight.follow(frontRight.speed);
        fLeft.follow(frontLeft.speed);
        bLeft.follow(backLeft.speed);
        bRight.follow(backRight.speed);
        
        
        frontRight.angle = wa1;
        frontLeft.angle = wa2;
        backLeft.angle = wa3;
        backRight.angle = wa4;
        
        fRightVector = new PVector(sin(frontRight.angle)*frontRight.speed,cos(frontRight.angle)*frontRight.speed);
        fLeftVector = new PVector(sin(frontLeft.angle)*frontLeft.speed,cos(frontLeft.angle)*frontLeft.speed);
        bRightVector = new PVector(sin(backRight.angle)*backRight.speed,cos(backRight.angle)*backRight.speed);
        bLeftVector = new PVector(sin(backLeft.angle)*backLeft.speed,cos(backLeft.angle)*backLeft.speed);
        
        fRightVector.rotate(-currentAngle);
        fLeftVector.rotate(-currentAngle);
        bRightVector.rotate(-currentAngle);
        bLeftVector.rotate(-currentAngle);
        
        
        
        
        
        deltaMovement.add(fRightVector);
        deltaMovement.add(fLeftVector);
        deltaMovement.add(bLeftVector);
        deltaMovement.add(bRightVector);
        
        deltaMovement.x = (deltaMovement.x*maximumTravelVelocity)/4;
        deltaMovement.y = (deltaMovement.y*maximumTravelVelocity)/4;
        
        totalMovement.add(deltaMovement);
        
        pushMatrix();
        translate(totalMovement.get().x, -totalMovement.get().y);
        rotate(currentAngle);
        noFill();44344
        strokeWeight(5);
        stroke(0,255,255);
        rect(0,0,L,W);
        stroke(0,0,0);
        strokeWeight(1);
        fill(255, 234, 0);
        rect(0,-W/2,W,10);
        stroke(255, 158, 48);
        noFill();
        strokeWeight(5);
        ellipse(0,0,lookAheadRadius*2,lookAheadRadius*2);
        strokeWeight(1);
        frontRight.draw(false, frontRight.speed);
        frontLeft.draw(false, frontLeft.speed);
        backLeft.draw(false, backLeft.speed);
        backRight.draw(false, backRight.speed);
        popMatrix();78
        

        if (my_i < pathsToFollow.length && pathsToFollow.length > 0 && !manualInput) {
            if (pathsToFollow[my_i][closestPoint] !== pathsToFollow[my_i][pathsToFollow[my_i].length-1]) {
                drawPath(pathsToFollow[my_i], true, [0,255,0], [0,255,0],true,[255,0,255],10);
                pointToFollow = chooseFollowingPoint(totalMovement.get().x, totalMovement.get().y, lookAheadRadius, pathsToFollow[my_i]);
                targetAngle = pathsToFollow[my_i][closestPoint][3];

                
            }else{
                completePaths[my_i] = true;
                my_i+=1;
                closestPoint = [];
                currentIndex = 0;
                otherCurrentIndex = 0;
                
                // Causes sim robot to drive forever after path is completed because intersectionPoint becomes NaN
                //prevIntersectionPoint = [];
                //intersectionPoint = [];
            }
        }else {
            
        }
        if (count === 3) {
            //poses.push([totalMovement.x,-totalMovement.y]);
            count = 0;
        }else {
            count+=1;
        }

        for (var i = 0; i < poses.length; i++) {
            fill(0, 255, 255);
            strokeWeight(1);
            stroke(0, 0, 0);
            ellipse(poses[i][0], poses[i][1], 5, 5);
        }
        stroke(0,0,0);
        otherAverage = (frameCount-deltaFrames)/framesPerSecond;
        otherAverage = otherAverage.toFixed(4);
        text(otherAverage + " Seconds", 925, 500);
        text("Delta Movement = " + deltaMovement.mag(), 925, 400);
        text("Velocity = " + vel, 925, 300);
        
    }

    if (createCSV) {
        csv = createCSVfile(newPath);
        localStorage.csvString = csv;
        localStorage.csv = csv;
        eWasPressed = true;
        createCSV = false;
    }
    };
}




createProcessing(main);